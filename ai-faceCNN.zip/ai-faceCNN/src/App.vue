<script setup>
import {ref} from 'vue'
import {mobilenet,modelmesh} from './mobileNet';
import {model}  from './model';
import { computed } from 'vue';

const video=ref();
let mediaStream;
let InputData=[];
let OutputData=[];
let imageUrl=ref();
let theName=ref(null);
let class1Counter=ref(0);
let class2Counter=ref(0);
let hightestIndex=ref(null);
let myprediction=ref(null);
let theFeatures2=ref(null);
let checkCase=ref(false);
let theCount=ref(0);
let theLeft=ref(0);
let theTop=ref(0);
let theRight=ref(0);
let countPictures=ref()
let checkTakePicture=ref();
let predictMode=ref(false);
let gatherid=ref();
let trainMode=ref(null);
let myModel=ref();
let theUnits=ref();
let theButtons=ref([]);
let lookUp=ref([]);
let totalPersons=ref();


const openCam=() =>{
    navigator.mediaDevices.getUserMedia({video:true,width:640,height:400,audio:false}).then(stream =>{
    mediaStream= stream;
    video.value.srcObject= stream;
    video.value.play()
  })
}
openCam();



const addPerson=()=>{
  if(theName.value != null){
  theButtons.value.push(theButtons.value.length )
  lookUp.value.push(theName.value)
  theName.value=''
}
}



 const gatherData= async(e)=>{
 checkTakePicture.value=true
 gatherid.value=e.target.id;
 countPictures.value=0;
 if(testComputed.value){
var theInterval= setInterval( async function (){
  countPictures.value++;
  if(countPictures.value < 101 && testComputed.value ){
  //  const faces = await modelmesh.estimateFaces(video.value);
  //console.log(faces);
  //  theTop.value=faces[0].boundingBox.topLeft[1];
  //   theLeft.value=faces[0].boundingBox.topLeft[0];
  //   theRight.value=faces[0].boundingBox.bottomRight[0];
  //  console.log('the Left is :'+theLeft.value+'  and the right is : '+theRight.value);
 const videoFrame=tf.browser.fromPixels(video.value)
 const resizeImg=tf.image.resizeBilinear(videoFrame,[224,224],true);
 const resizedImgTensor= resizeImg.div(255)
 const theFeatures=mobilenet.predict(resizedImgTensor.expandDims()).squeeze()

//  theFeatures2.value=theFeatures.arraySync()
//  console.log(theFeatures2.value)
//  theFeatures.print()
 InputData.push(theFeatures)
  let outInt=parseInt(gatherid.value)
  OutputData.push(outInt);
  theCount.value++
}else{
  checkTakePicture.value=false
    clearInterval(theInterval)
}
 },10)
 
}
}
 
const testComputed=computed(()=>{
 return checkTakePicture.value
})

const testTrain=computed(()=>{
  if(theButtons.value.length == 0){
    return 2;
  }
 return theButtons.value.length
})





const stopTakingPictures=()=>{
checkTakePicture.value=false
}

const theTrain= async()=>{ 
trainMode.value=true;
theUnits.value=theButtons.value.length;
// let model=thefunGo();
tf.util.shuffleCombo(InputData,OutputData);
let OutputDataTensor=tf.tensor1d(OutputData,'int32')
let ontHotOutput=tf.oneHot(OutputDataTensor,theButtons.value.length)
let inputDataTensor=tf.stack(InputData)

model.fit(inputDataTensor,ontHotOutput,{
  shuffle:true,
  batchSize:5,
  epochs:10,
  callbacks:{onEpochEnd:logProgress}
})
function logProgress(epochs,logs){
  console.log('Data for epochs : '+epochs,logs)
}
}

const predict= async ()=>{
// const model= await tf.loadLayersModel('model.json')
 //const mobilenet= await tf.loadGraphModel('mobilenet.json')
predictMode.value=true;

let frameImage=tf.browser.fromPixels(video.value)
let resizeFrameImage=tf.image.resizeBilinear(frameImage,[224,224],true).expandDims()
let normalizedImage=resizeFrameImage.div(255)
let ImageTensor=mobilenet.predict(normalizedImage)
let prediction=model.predict(ImageTensor).squeeze()
hightestIndex.value=prediction.argMax().arraySync()
myprediction.value=prediction.arraySync()
console.log(hightestIndex.value);
console.log(myprediction.value);

}
const Download=()=>{
model.save('downloads://model')
mobilenet.save('downloads://mobilenet')
}


</script>


<template>
<div class='m-5  grid grid-cols-2 gap-2'>
<div>
<div class="relative">
<video ref="video"  width="440" height="280" class=" border border-r-gray-600 rounded"></video>
<!-- <div class=" absolute rounded-full  " v-if="theLeft" :style="{width:'100px',height:'150px',top:theTop -10 +'px',left:theLeft - 44 +'px',border:'solid 1px aqua'}"></div> -->
</div>
<!-- <p v-if="theFeatures2">{{ theFeatures2 }}</p> -->
<div class='flex' v-if='checkTakePicture'>
<svg class="spinner" width="30px" height="30px" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
   <circle class="path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle>
</svg><p class='pl-2'>taking pictures</p>
</div>
<button @click="gatherData"   v-for="(button,index) in theButtons" :id= button  class="bg-black text-white rounded p-1  m-1" v-if='!predictMode && !checkTakePicture && !trainMode'>Taking Pictures for {{ lookUp[button] }}</button>


<br>
<input type="text" v-if='!predictMode && !checkTakePicture && !trainMode'  placeholder="The Name of Person" v-model="theName" class="bg-black text-white rounded p-1 m-1">
<button @click="addPerson" v-if='!predictMode && !checkTakePicture && !trainMode' class="bg-black text-white rounded p-1 m-1">add person <i class="fa-solid fa-plus"></i></button>
<!-- <button @click="stopTakingPictures" v-if="checkTakePicture" class="bg-black text-white rounded p-1 m-1">stop Taking Pictures for {{ lookUp[gatherid] }}</button> -->
<br><br>
<button @click="theTrain" v-if="lookUp.length >= 2 && !predictMode && !trainMode && OutputData.length == theButtons.length * 100" class="bg-[#22d3ee] text-white rounded p-1 m-1">Train</button>
<button @click='predict' v-if="lookUp.length >= 2  && OutputData.length == theButtons.length * 100"  class="bg-[#a21caf] text-white rounded p-1 m-1">Predict</button><br>
<p class='p-1 font-bold text-green-800' v-if='hightestIndex != null'>The result is : the name on video is {{ lookUp[hightestIndex]}} with accuracy {{Math.trunc(myprediction[hightestIndex] * 100) }}% </p>
<br>
<div v-if='lookUp.length >= 2 && OutputData.length == theButtons.length * 100 && predictMode'>
<p class='m-2' >If you like the  results ! Download the models ... </p>
<hr>
</div>
<br>
<button @click='Download' v-if="lookUp.length >= 2 && OutputData.length == theButtons.length * 100 && predictMode"  class="bg-black text-white rounded p-1 m-1">Download Models <i class="fa-solid fa-download"></i></button>
</div>
<div class='grid grid-flow-row auto-rows-max grid-cols-3 ' >
  <p class='bg-[#f59e0b] text-white rounded m-1 p-1 ' v-for="(person,index) in lookUp"> {{ person }} has <span hidden>{{ countPictures }}</span> {{ OutputData.filter(value => value == index).length }} pictures</p>
<!-- <p v-if="hightestIndex !== null">{{ lookUp[hightestIndex] }} with {{ myprediction[hightestIndex] * 100 }} </p> -->
</div>
</div>
</template>  