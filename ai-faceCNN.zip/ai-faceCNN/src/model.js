
let model=tf.sequential()
model.add(tf.layers.dense({inputShape:[1024],units:128,activation:'relu'}))
model.add(tf.layers.dense({units:2,activation:'softmax'}))

model.compile({
    optimizer:'adam',
    loss:'binaryCrossentropy',
    metrics:'accuracy'
})


export{model}